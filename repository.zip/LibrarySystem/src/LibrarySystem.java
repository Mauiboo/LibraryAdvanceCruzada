public class LibrarySystem {

	public static void main(String[] args) {
	
		HomePage homepage = new HomePage();
		
	}

}
