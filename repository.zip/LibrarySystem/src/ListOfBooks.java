import java.awt.Color;
	import java.awt.FlowLayout;
	import java.awt.Font;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
	

public class ListOfBooks extends JFrame implements ActionListener{
		
		JFrame frame = new JFrame();
		JLabel label = new JLabel("");
		JButton button;
		
		ListOfBooks() {
			
			label.setBounds(100, 100, 200, 50);
			label.setFont(new Font("Arial", Font.PLAIN,20));
			label.setForeground(Color.BLUE);
			
			JCheckBox checkBox1 = new JCheckBox();
			checkBox1.setBounds(22, 103, 325, 14);
			this.setLayout(new FlowLayout());
			this.pack();
			this.add(checkBox1);
			this.setVisible(true);
			checkBox1.setText("System Analysis and Design");
			
			JCheckBox checkBox2 = new JCheckBox();
			this.setLayout(new FlowLayout());
			checkBox2.setBounds(22, 128, 325, 14);
			this.pack();
			this.add(checkBox2);
			this.setVisible(true);
			checkBox2.setText("Android Application");
			
			JCheckBox checkBox3 = new JCheckBox();
			this.setLayout(new FlowLayout());
			checkBox3.setBounds(22, 153, 325, 14);
			this.pack();
			this.add(checkBox3);
			this.setVisible(true);
			checkBox3.setText("Programming Concepts and Logic Formula");
			
			button = new JButton();
			button.setText("Submit");
			button.addActionListener(null);
			this.add(button);
			
			checkBox1.setSize(getPreferredSize());

		}

		
	/*		frame.add(label);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(600, 600);
			frame.setLayout(null);
			frame.setVisible(true);
			frame.setLocationRelativeTo(null);
			
			ImageIcon image = new ImageIcon("NU.png");
			frame.setIconImage(image.getImage());
		}
			JLabel Label1 = new JLabel("System Analysis and Design by Gary B. Shelly (1991).");
			Label1.setFont(new Font("Tahoma", Font.PLAIN, 12));
			Label1.setBounds(22, 103, 325, 14);
			frame.getContentPane().add(Label1);

			JLabel Label2 = new JLabel("Android Application by Corine Hoisington (2012).");
			Label2.setFont(new Font("Tahoma", Font.PLAIN, 12));
			Label2.setBounds(22, 128, 325, 14);
			frame.getContentPane().add(Label2);
			
			JLabel Label3 = new JLabel("Programming Concepts and Logic Formulation");
			Label3.setFont(new Font("Tahoma", Font.PLAIN, 12));
			Label3.setBounds(22, 153, 325, 14);
	*///		frame.getContentPane().add(Label3);
			
			
			
			
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == button) {
				JOptionPane.showMessageDialog(null, "YOU RENTED A BOOK: ");				
			}
		}
	}
		

